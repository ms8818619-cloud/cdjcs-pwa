/* Service Worker — Casa de Jurema Caboclo Samambaia (CDJCS)
 * Estratégia:
 *  - App shell (HTML/CSS/JS/ícones): cache-first com atualização em segundo plano
 *  - Chamadas de API (/api/...): network-first, sem cache de dados sensíveis
 *  - Navegação offline: retorna o index.html em cache (fallback SPA)
 */

const CACHE_VERSION = "cdjcs-v1";
const APP_SHELL_CACHE = `${CACHE_VERSION}-shell`;
const RUNTIME_CACHE = `${CACHE_VERSION}-runtime`;

const APP_SHELL_FILES = [
  "/",
  "/index.html",
  "/manifest.webmanifest",
  "/favicon.ico",
  "/icons/icon-192.png",
  "/icons/icon-512.png",
  "/icons/icon-maskable-192.png",
  "/icons/icon-maskable-512.png",
  "/icons/apple-touch-icon.png",
  "/brasao.jpg",
];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches
      .open(APP_SHELL_CACHE)
      .then((cache) => cache.addAll(APP_SHELL_FILES))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches
      .keys()
      .then((keys) =>
        Promise.all(
          keys
            .filter((key) => key.startsWith("cdjcs-") && key !== APP_SHELL_CACHE && key !== RUNTIME_CACHE)
            .map((key) => caches.delete(key))
        )
      )
      .then(() => self.clients.claim())
  );
});

function isApiRequest(url) {
  return url.pathname.startsWith("/api/");
}

function isStaticAsset(url) {
  return /\.(?:js|css|png|jpg|jpeg|svg|webp|ico|woff2?|ttf)$/.test(url.pathname);
}

self.addEventListener("fetch", (event) => {
  const { request } = event;
  if (request.method !== "GET") return;

  const url = new URL(request.url);

  // Never intercept cross-origin requests (backend API on another domain, analytics, fonts CDN, etc.)
  if (url.origin !== self.location.origin) return;

  // API calls: network-first, never cached long-term (keeps data — pagamentos, avisos, etc. — sempre atual)
  if (isApiRequest(url)) {
    event.respondWith(
      fetch(request).catch(() =>
        caches.match(request).then((cached) => cached || Response.error())
      )
    );
    return;
  }

  // Static assets & app shell: cache-first, refresh in background (stale-while-revalidate)
  if (isStaticAsset(url) || url.pathname === "/" || url.pathname === "/index.html") {
    event.respondWith(
      caches.match(request).then((cached) => {
        const networkFetch = fetch(request)
          .then((response) => {
            if (response && response.status === 200) {
              const clone = response.clone();
              caches.open(RUNTIME_CACHE).then((cache) => cache.put(request, clone));
            }
            return response;
          })
          .catch(() => null);

        return cached || networkFetch || caches.match("/index.html");
      })
    );
    return;
  }

  // Navigation requests (SPA routes like /app, /bem-vindo): try network, fall back to cached shell
  if (request.mode === "navigate") {
    event.respondWith(
      fetch(request).catch(() => caches.match("/index.html"))
    );
    return;
  }
});
