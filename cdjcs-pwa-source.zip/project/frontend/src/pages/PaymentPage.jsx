import React, { useEffect, useState } from "react";
import { toast } from "sonner";
import { api, currencyBRL, MONTHS_PT } from "../lib/api";
import { CheckCircle2, AlertTriangle, Copy, QrCode, FileText, History } from "lucide-react";

export default function PaymentPage() {
  const [status, setStatus] = useState(null);
  const [settings, setSettings] = useState(null);
  const [history, setHistory] = useState([]);
  const [tab, setTab] = useState("pix");

  const load = () => {
    api.get("/payments/me/status").then(r => setStatus(r.data)).catch(() => {});
    api.get("/settings").then(r => setSettings(r.data)).catch(() => {});
    api.get("/payments/me").then(r => setHistory(r.data)).catch(() => {});
  };

  useEffect(() => { load(); }, []);

  const now = new Date();
  const emDia = status?.status === "em_dia";
  const pixCode = settings?.pix_code || "";
  const autoQr = pixCode
    ? `https://api.qrserver.com/v1/create-qr-code/?size=280x280&margin=8&data=${encodeURIComponent(pixCode)}`
    : "";
  const qrUrl = settings?.pix_qr_image || autoQr;

  const copy = async () => {
    if (!pixCode) return toast.error("Código Pix ainda não configurado.");
    try {
      await navigator.clipboard.writeText(pixCode);
      toast.success("Código Pix copiado!");
    } catch { toast.error("Não foi possível copiar."); }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 md:px-6 py-8 md:py-12" data-testid="payment-page">
      <div className="animate-fade-in">
        <div className="text-[11px] tracking-[0.3em] uppercase text-terreiro-terracotta font-semibold">Contribuição Mensal</div>
        <h1 className="font-display text-4xl sm:text-5xl text-terreiro-navy-deep mt-2">Manter a Casa</h1>
        <p className="text-terreiro-navy/70 mt-2 max-w-2xl">
          Sua contribuição sustenta a manutenção do terreiro, os trabalhos espirituais e as ações da comunidade.
        </p>
      </div>

      <div className="mt-8 grid gap-6 lg:grid-cols-3">
        <div className="navy-card rounded-2xl p-7 lg:col-span-1 animate-fade-in">
          <div className="text-[11px] tracking-[0.3em] uppercase text-terreiro-gold-soft/90">
            {MONTHS_PT[now.getMonth()]} · {now.getFullYear()}
          </div>
          <div className="mt-2 font-display text-5xl text-terreiro-cream" data-testid="payment-amount">
            {currencyBRL(status?.amount || settings?.monthly_amount || 0)}
          </div>
          <div className="mt-4 inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full border"
               style={{
                 borderColor: emDia ? "rgba(200,168,90,0.6)" : "rgba(180,89,58,0.7)",
                 background: emDia ? "rgba(200,168,90,0.15)" : "rgba(180,89,58,0.15)",
               }}
               data-testid="payment-status">
            {emDia ? <CheckCircle2 size={16} className="text-terreiro-gold-soft" /> : <AlertTriangle size={16} className="text-terreiro-terracotta" />}
            <span className="text-xs uppercase tracking-widest font-semibold">
              {emDia ? "Em dia" : "Em atraso"}
            </span>
          </div>
          {status?.last_paid && !emDia && (
            <div className="mt-6 text-xs text-terreiro-cream/70">
              Último pagamento: {MONTHS_PT[(status.last_paid.month || 1) - 1]}/{status.last_paid.year}
            </div>
          )}
        </div>

        <div className="parchment-card rounded-2xl p-6 lg:col-span-2 animate-fade-in" style={{ animationDelay: "0.1s" }}>
          <div className="flex items-center gap-2 border-b border-terreiro-gold/25 pb-3">
            <button
              onClick={() => setTab("pix")}
              data-testid="tab-pix"
              className={`px-4 py-1.5 rounded-full text-sm font-medium transition-all ${tab==='pix' ? 'bg-terreiro-navy text-terreiro-cream' : 'text-terreiro-navy/70 hover:bg-terreiro-gold/15'}`}
            >
              <QrCode size={14} className="inline mr-1.5" /> Pix
            </button>
            <button
              onClick={() => setTab("boleto")}
              data-testid="tab-boleto"
              className={`px-4 py-1.5 rounded-full text-sm font-medium transition-all ${tab==='boleto' ? 'bg-terreiro-navy text-terreiro-cream' : 'text-terreiro-navy/70 hover:bg-terreiro-gold/15'}`}
            >
              <FileText size={14} className="inline mr-1.5" /> Boleto
            </button>
          </div>

          {tab === "pix" && (
            <div className="mt-5 space-y-5">
              {(settings?.pix_bank || settings?.pix_holder_name || settings?.pix_key) && (
                <div className="rounded-lg bg-terreiro-navy/5 border border-terreiro-gold/30 p-4" data-testid="pix-receiver-info">
                  <div className="text-[10px] uppercase tracking-widest text-terreiro-terracotta font-semibold mb-2">
                    Você está enviando para
                  </div>
                  <div className="grid sm:grid-cols-3 gap-3 text-sm">
                    <div>
                      <div className="text-terreiro-navy/60 text-[10px] uppercase tracking-widest">Banco</div>
                      <div className="text-terreiro-navy-deep font-semibold" data-testid="pix-bank">{settings?.pix_bank || "—"}</div>
                    </div>
                    <div>
                      <div className="text-terreiro-navy/60 text-[10px] uppercase tracking-widest">Titular</div>
                      <div className="text-terreiro-navy-deep font-semibold" data-testid="pix-holder">{settings?.pix_holder_name || "—"}</div>
                    </div>
                    <div className="min-w-0">
                      <div className="text-terreiro-navy/60 text-[10px] uppercase tracking-widest">Chave Pix</div>
                      <div className="text-terreiro-navy-deep font-mono text-xs break-all" data-testid="pix-key-display">{settings?.pix_key || "—"}</div>
                    </div>
                  </div>
                </div>
              )}
              <div className="grid sm:grid-cols-[auto,1fr] gap-6 items-start">
                <div className="flex flex-col items-center">
                  {qrUrl ? (
                    <img src={qrUrl} alt="QR Code Pix" className="rounded-lg border border-terreiro-gold/40 bg-white p-2 w-[260px] h-[260px] object-contain" data-testid="pix-qr" />
                  ) : (
                    <div className="w-[260px] h-[260px] rounded-lg border border-dashed border-terreiro-gold/40 flex items-center justify-center text-sm text-terreiro-navy/60 bg-terreiro-ivory text-center px-4">
                      QR Code não configurado
                    </div>
                  )}
                  <div className="text-[10px] uppercase tracking-widest text-terreiro-navy/60 mt-2">
                    {settings?.pix_qr_image ? "QR enviado pelo administrador" : "QR gerado a partir do código Pix"}
                  </div>
                </div>
                <div>
                  <label className="block text-xs uppercase tracking-widest text-terreiro-navy/70 mb-2">
                    Pix Copia e Cola
                  </label>
                  <textarea
                    data-testid="pix-code"
                    readOnly
                    value={pixCode || "O administrador ainda não configurou o código Pix."}
                    className="w-full h-32 p-3 rounded-lg bg-terreiro-ivory border border-terreiro-gold/40 font-mono text-xs text-terreiro-navy-deep resize-none"
                  />
                  <button
                    onClick={copy}
                    data-testid="btn-copy-pix"
                    className="btn-gold mt-3 inline-flex items-center gap-2 h-10 px-4 rounded-full text-sm font-semibold"
                  >
                    <Copy size={14} /> Copiar código
                  </button>
                  <p className="mt-4 text-xs text-terreiro-navy/60">
                    Após o pagamento, avise o administrador. Ele confirmará seu status como &quot;Em dia&quot;.
                  </p>
                </div>
              </div>
            </div>
          )}

          {tab === "boleto" && (
            <div className="mt-5">
              <label className="block text-xs uppercase tracking-widest text-terreiro-navy/70 mb-2">
                Boleto / Instruções
              </label>
              <div className="p-4 rounded-lg bg-terreiro-ivory border border-terreiro-gold/40 text-sm text-terreiro-navy-deep whitespace-pre-wrap" data-testid="boleto-info">
                {settings?.boleto_info || "O administrador ainda não configurou informações de boleto."}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* History */}
      <div className="mt-10 parchment-card rounded-2xl p-6 animate-fade-in" style={{ animationDelay: "0.2s" }}>
        <div className="flex items-center gap-2 text-terreiro-navy-deep">
          <History size={18} className="text-terreiro-olive" />
          <h3 className="font-display text-2xl">Histórico de pagamentos</h3>
        </div>
        <div className="mt-4 overflow-x-auto" data-testid="payment-history">
          <table className="w-full text-sm">
            <thead>
              <tr className="text-left text-xs uppercase tracking-widest text-terreiro-navy/60">
                <th className="py-2 pr-4">Mês</th>
                <th className="py-2 pr-4">Ano</th>
                <th className="py-2 pr-4">Valor</th>
                <th className="py-2 pr-4">Status</th>
                <th className="py-2 pr-4">Método</th>
                <th className="py-2 pr-4">Pago em</th>
              </tr>
            </thead>
            <tbody>
              {history.length === 0 && (
                <tr><td colSpan={6} className="py-6 text-center text-terreiro-navy/60">Nenhum registro ainda.</td></tr>
              )}
              {history.map(p => (
                <tr key={p.id} className="border-t border-terreiro-gold/20">
                  <td className="py-3 pr-4">{MONTHS_PT[p.month - 1]}</td>
                  <td className="py-3 pr-4">{p.year}</td>
                  <td className="py-3 pr-4">{currencyBRL(p.amount)}</td>
                  <td className="py-3 pr-4">
                    <span className={`inline-flex px-2 py-0.5 rounded-full text-xs font-semibold ${
                      p.status === 'paid' ? 'bg-terreiro-olive/15 text-terreiro-olive' :
                      p.status === 'overdue' ? 'bg-terreiro-terracotta/15 text-terreiro-terracotta' :
                      'bg-terreiro-gold/20 text-terreiro-navy-deep'
                    }`}>
                      {p.status === 'paid' ? 'Pago' : p.status === 'overdue' ? 'Em atraso' : 'Pendente'}
                    </span>
                  </td>
                  <td className="py-3 pr-4 capitalize">{p.method || '-'}</td>
                  <td className="py-3 pr-4 text-terreiro-navy/70">{p.paid_at ? new Date(p.paid_at).toLocaleDateString('pt-BR') : '-'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
