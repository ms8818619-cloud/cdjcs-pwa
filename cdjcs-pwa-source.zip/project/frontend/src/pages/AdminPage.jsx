import React, { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import { api, currencyBRL, formatCPF, maskCPFInput, MONTHS_PT, EVENT_CATEGORIES } from "../lib/api";
import { Users, Wallet, Calendar, Bell, Settings as SettingsIcon, BarChart3, Plus, Pencil, Trash2, Check, X } from "lucide-react";
import PhotoPicker from "../components/PhotoPicker";
import Avatar from "../components/Avatar";

const TABS = [
  { key: "members", label: "Membros", icon: Users },
  { key: "payments", label: "Pagamentos", icon: Wallet },
  { key: "payment_config", label: "Config. Pagamento", icon: Wallet },
  { key: "events", label: "Eventos", icon: Calendar },
  { key: "notices", label: "Avisos", icon: Bell },
  { key: "settings", label: "Configurações", icon: SettingsIcon },
  { key: "reports", label: "Relatórios", icon: BarChart3 },
];

export default function AdminPage() {
  const [tab, setTab] = useState("members");
  return (
    <div className="max-w-7xl mx-auto px-4 md:px-6 py-8 md:py-12" data-testid="admin-page">
      <div className="animate-fade-in">
        <div className="text-[11px] tracking-[0.3em] uppercase text-terreiro-terracotta font-semibold">Área Restrita</div>
        <h1 className="font-display text-4xl sm:text-5xl text-terreiro-navy-deep mt-2">Painel do Administrador</h1>
      </div>
      <div className="mt-6 flex flex-wrap gap-2">
        {TABS.map(({ key, label, icon: Icon }) => (
          <button
            key={key}
            data-testid={`admin-tab-${key}`}
            onClick={() => setTab(key)}
            className={`inline-flex items-center gap-2 px-4 py-2 rounded-full text-sm transition-all ${
              tab === key ? "bg-terreiro-navy text-terreiro-cream shadow-md" : "bg-terreiro-cream border border-terreiro-gold/30 text-terreiro-navy-deep hover:bg-terreiro-gold/15"
            }`}
          >
            <Icon size={14} /> {label}
          </button>
        ))}
      </div>
      <div className="mt-6">
        {tab === "members" && <MembersTab />}
        {tab === "payments" && <PaymentsTab />}
        {tab === "payment_config" && <PaymentConfigTab />}
        {tab === "events" && <EventsTab />}
        {tab === "notices" && <NoticesTab />}
        {tab === "settings" && <SettingsTab />}
        {tab === "reports" && <ReportsTab />}
      </div>
    </div>
  );
}

// ---------- Members ----------
function MembersTab() {
  const [list, setList] = useState([]);
  const [form, setForm] = useState({ name: "", cpf: "", phone: "", is_admin: false, photo: null });
  const [editing, setEditing] = useState(null);
  const [viewing, setViewing] = useState(null);

  const load = () => api.get("/members").then(r => setList(r.data)).catch(() => {});
  useEffect(() => { load(); }, []);

  const save = async (e) => {
    e.preventDefault();
    try {
      const payload = { ...form, cpf: form.cpf.replace(/\D/g, "") };
      if (editing) {
        await api.put(`/members/${editing}`, payload);
        toast.success("Membro atualizado.");
      } else {
        await api.post("/members", payload);
        toast.success("Membro cadastrado.");
      }
      setForm({ name: "", cpf: "", phone: "", is_admin: false, photo: null });
      setEditing(null);
      load();
    } catch (err) { toast.error(err?.response?.data?.detail || "Erro"); }
  };

  const startEdit = (m) => {
    setEditing(m.id);
    setForm({ name: m.name, cpf: formatCPF(m.cpf), phone: m.phone || "", is_admin: !!m.is_admin, photo: m.photo || null });
  };
  const cancelEdit = () => { setEditing(null); setForm({ name: "", cpf: "", phone: "", is_admin: false, photo: null }); };
  const del = async (m) => {
    if (!window.confirm(`Remover ${m.name}?`)) return;
    try { await api.delete(`/members/${m.id}`); toast.success("Removido."); load(); }
    catch (err) { toast.error(err?.response?.data?.detail || "Erro"); }
  };

  return (
    <div className="grid lg:grid-cols-[380px,1fr] gap-6">
      <form onSubmit={save} className="parchment-card rounded-2xl p-6 space-y-3 h-fit" data-testid="member-form">
        <h3 className="font-display text-2xl text-terreiro-navy-deep">{editing ? "Editar membro" : "Novo membro"}</h3>
        <PhotoPicker value={form.photo} onChange={(v) => setForm(f => ({ ...f, photo: v }))} />
        <Field label="Nome completo">
          <input required data-testid="member-name" value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} className={inputCls} />
        </Field>
        <Field label="CPF">
          <input required data-testid="member-cpf" value={form.cpf} onChange={e => setForm(f => ({ ...f, cpf: maskCPFInput(e.target.value) }))} placeholder="000.000.000-00" className={inputCls} />
        </Field>
        <Field label="Telefone">
          <input data-testid="member-phone" value={form.phone} onChange={e => setForm(f => ({ ...f, phone: e.target.value }))} placeholder="(11) 91234-5678" className={inputCls} />
        </Field>
        <label className="flex items-center gap-2 text-sm text-terreiro-navy-deep">
          <input type="checkbox" data-testid="member-is-admin" checked={form.is_admin} onChange={e => setForm(f => ({ ...f, is_admin: e.target.checked }))} />
          É administrador
        </label>
        <div className="flex gap-2 pt-2">
          <button type="submit" data-testid="member-save" className="btn-gold h-10 px-5 rounded-full text-sm font-semibold flex-1">
            {editing ? "Salvar" : "Cadastrar"}
          </button>
          {editing && <button type="button" onClick={cancelEdit} className="h-10 px-4 rounded-full text-sm border border-terreiro-gold/40">Cancelar</button>}
        </div>
      </form>
      <div className="parchment-card rounded-2xl p-4 sm:p-6 overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="text-left text-xs uppercase tracking-widest text-terreiro-navy/60">
              <th className="py-2 pr-4">Foto</th><th className="py-2 pr-4">Nome</th><th className="py-2 pr-4">CPF</th><th className="py-2 pr-4">Telefone</th><th className="py-2 pr-4">Admin</th><th className="py-2 pr-4"></th>
            </tr>
          </thead>
          <tbody>
            {list.map(m => (
              <tr key={m.id} className="border-t border-terreiro-gold/20" data-testid={`member-row-${m.id}`}>
                <td className="py-3 pr-4">
                  <button onClick={() => setViewing(m)} className="hover:opacity-80" data-testid={`view-member-${m.id}`}>
                    <Avatar photo={m.photo} name={m.name} size={40} />
                  </button>
                </td>
                <td className="py-3 pr-4 font-medium text-terreiro-navy-deep">{m.name}</td>
                <td className="py-3 pr-4">{formatCPF(m.cpf)}</td>
                <td className="py-3 pr-4">{m.phone || "-"}</td>
                <td className="py-3 pr-4">{m.is_admin ? <Check size={16} className="text-terreiro-olive" /> : <X size={16} className="text-terreiro-navy/40" />}</td>
                <td className="py-3 pr-4 text-right whitespace-nowrap">
                  <button onClick={() => startEdit(m)} className="p-1.5 rounded hover:bg-terreiro-gold/20 text-terreiro-navy" data-testid={`edit-member-${m.id}`}><Pencil size={14} /></button>
                  <button onClick={() => del(m)} className="p-1.5 rounded hover:bg-terreiro-terracotta/15 text-terreiro-terracotta" data-testid={`del-member-${m.id}`}><Trash2 size={14} /></button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {viewing && <MemberCardModal member={viewing} onClose={() => setViewing(null)} />}
    </div>
  );
}

function MemberCardModal({ member, onClose }) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-terreiro-navy-deep/70 backdrop-blur-sm animate-fade-in-slow" onClick={onClose} data-testid="member-card-modal">
      <div className="parchment-card rounded-2xl p-6 max-w-md w-full" onClick={e => e.stopPropagation()}>
        <div className="flex items-center justify-between">
          <div className="text-[10px] uppercase tracking-widest text-terreiro-terracotta font-semibold">Ficha do membro</div>
          <button onClick={onClose} className="p-1 rounded hover:bg-terreiro-gold/15 text-terreiro-navy" data-testid="close-member-card"><X size={18} /></button>
        </div>
        <div className="mt-4 flex items-center gap-4">
          <Avatar photo={member.photo} name={member.name} size={96} className="!border-2" />
          <div className="min-w-0">
            <div className="font-display text-2xl text-terreiro-navy-deep leading-tight">{member.name}</div>
            <div className="text-xs uppercase tracking-widest text-terreiro-navy/60 mt-1">
              {member.is_admin ? "Administrador" : "Membro"}
            </div>
          </div>
        </div>
        <div className="gold-divider my-5" />
        <dl className="space-y-2 text-sm">
          <div className="flex justify-between"><dt className="text-terreiro-navy/60">CPF</dt><dd className="text-terreiro-navy-deep font-medium">{formatCPF(member.cpf)}</dd></div>
          <div className="flex justify-between"><dt className="text-terreiro-navy/60">Telefone</dt><dd className="text-terreiro-navy-deep font-medium">{member.phone || "—"}</dd></div>
          <div className="flex justify-between"><dt className="text-terreiro-navy/60">Cadastrado em</dt><dd className="text-terreiro-navy-deep font-medium">{member.created_at ? new Date(member.created_at).toLocaleDateString("pt-BR") : "—"}</dd></div>
        </dl>
      </div>
    </div>
  );
}

// ---------- Payments ----------
function PaymentsTab() {
  const now = new Date();
  const [year, setYear] = useState(now.getFullYear());
  const [month, setMonth] = useState(now.getMonth() + 1);
  const [members, setMembers] = useState([]);
  const [payments, setPayments] = useState([]);
  const [form, setForm] = useState({ member_id: "", amount: "", status: "paid", method: "pix", notes: "" });

  const load = () => {
    api.get("/members").then(r => setMembers(r.data)).catch(() => {});
    api.get(`/payments?year=${year}&month=${month}`).then(r => setPayments(r.data)).catch(() => {});
    api.get("/settings").then(r => setForm(f => f.amount ? f : { ...f, amount: r.data?.monthly_amount || "" }));
  };
  useEffect(() => { load(); }, [year, month]); // eslint-disable-line

  const paymentByMember = useMemo(() => {
    const map = {}; payments.forEach(p => { map[p.member_id] = p; }); return map;
  }, [payments]);

  const submit = async (e) => {
    e.preventDefault();
    try {
      const existing = paymentByMember[form.member_id];
      const body = { ...form, amount: Number(form.amount), month, year };
      if (existing) {
        await api.put(`/payments/${existing.id}`, { status: body.status, amount: body.amount, method: body.method, notes: body.notes });
      } else {
        await api.post("/payments", body);
      }
      toast.success("Pagamento registrado.");
      load();
    } catch (err) { toast.error(err?.response?.data?.detail || "Erro"); }
  };

  const toggle = async (p, status) => {
    try { await api.put(`/payments/${p.id}`, { status }); toast.success("Status atualizado."); load(); }
    catch (err) { toast.error(err?.response?.data?.detail || "Erro"); }
  };

  const del = async (p) => {
    if (!window.confirm("Remover registro?")) return;
    try { await api.delete(`/payments/${p.id}`); load(); } catch { toast.error("Erro"); }
  };

  return (
    <div className="space-y-6">
      <div className="parchment-card rounded-2xl p-6 flex flex-wrap items-end gap-4">
        <Field label="Mês">
          <select value={month} onChange={e => setMonth(Number(e.target.value))} className={inputCls} data-testid="pay-filter-month">
            {MONTHS_PT.map((m, i) => <option key={i} value={i + 1}>{m}</option>)}
          </select>
        </Field>
        <Field label="Ano">
          <input type="number" value={year} onChange={e => setYear(Number(e.target.value))} className={inputCls} data-testid="pay-filter-year" />
        </Field>
      </div>
      <form onSubmit={submit} className="parchment-card rounded-2xl p-6 grid sm:grid-cols-2 lg:grid-cols-5 gap-3 items-end" data-testid="payment-form">
        <Field label="Membro">
          <select required value={form.member_id} onChange={e => setForm(f => ({ ...f, member_id: e.target.value }))} className={inputCls} data-testid="pay-member">
            <option value="">Selecione...</option>
            {members.filter(m => !m.is_admin).map(m => <option key={m.id} value={m.id}>{m.name}</option>)}
          </select>
        </Field>
        <Field label="Valor">
          <input required type="number" step="0.01" value={form.amount} onChange={e => setForm(f => ({ ...f, amount: e.target.value }))} className={inputCls} data-testid="pay-amount" />
        </Field>
        <Field label="Status">
          <select value={form.status} onChange={e => setForm(f => ({ ...f, status: e.target.value }))} className={inputCls}>
            <option value="paid">Pago</option><option value="pending">Pendente</option><option value="overdue">Em atraso</option>
          </select>
        </Field>
        <Field label="Método">
          <select value={form.method} onChange={e => setForm(f => ({ ...f, method: e.target.value }))} className={inputCls}>
            <option value="pix">Pix</option><option value="boleto">Boleto</option><option value="dinheiro">Dinheiro</option><option value="outro">Outro</option>
          </select>
        </Field>
        <button type="submit" data-testid="pay-save" className="btn-gold h-10 px-4 rounded-full text-sm font-semibold"><Plus size={14} className="inline mr-1" />Registrar</button>
      </form>

      <div className="parchment-card rounded-2xl p-4 sm:p-6 overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="text-left text-xs uppercase tracking-widest text-terreiro-navy/60">
              <th className="py-2 pr-4">Membro</th><th className="py-2 pr-4">CPF</th><th className="py-2 pr-4">Valor</th><th className="py-2 pr-4">Status</th><th className="py-2 pr-4">Método</th><th className="py-2 pr-4"></th>
            </tr>
          </thead>
          <tbody>
            {members.filter(m => !m.is_admin).map(m => {
              const p = paymentByMember[m.id];
              return (
                <tr key={m.id} className="border-t border-terreiro-gold/20">
                  <td className="py-3 pr-4 font-medium text-terreiro-navy-deep">{m.name}</td>
                  <td className="py-3 pr-4">{formatCPF(m.cpf)}</td>
                  <td className="py-3 pr-4">{p ? currencyBRL(p.amount) : "—"}</td>
                  <td className="py-3 pr-4">
                    {p ? (
                      <span className={`inline-flex px-2 py-0.5 rounded-full text-xs font-semibold ${
                        p.status === 'paid' ? 'bg-terreiro-olive/15 text-terreiro-olive' :
                        p.status === 'overdue' ? 'bg-terreiro-terracotta/15 text-terreiro-terracotta' :
                        'bg-terreiro-gold/20 text-terreiro-navy-deep'
                      }`}>
                        {p.status === 'paid' ? 'Pago' : p.status === 'overdue' ? 'Em atraso' : 'Pendente'}
                      </span>
                    ) : <span className="text-terreiro-navy/50 text-xs">Sem registro</span>}
                  </td>
                  <td className="py-3 pr-4 capitalize">{p?.method || "-"}</td>
                  <td className="py-3 pr-4 text-right whitespace-nowrap">
                    {p && p.status !== 'paid' && (
                      <button onClick={() => toggle(p, 'paid')} className="text-xs px-2 py-1 rounded bg-terreiro-olive/15 text-terreiro-olive mr-1" data-testid={`mark-paid-${p.id}`}>Marcar pago</button>
                    )}
                    {p && p.status === 'paid' && (
                      <button onClick={() => toggle(p, 'overdue')} className="text-xs px-2 py-1 rounded bg-terreiro-terracotta/15 text-terreiro-terracotta mr-1">Marcar atraso</button>
                    )}
                    {p && <button onClick={() => del(p)} className="p-1.5 rounded hover:bg-terreiro-terracotta/15 text-terreiro-terracotta"><Trash2 size={14} /></button>}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// ---------- Events ----------
function EventsTab() {
  const [list, setList] = useState([]);
  const [form, setForm] = useState({ title: "", description: "", category: "gira", date: "", time: "" });
  const [editing, setEditing] = useState(null);

  const load = () => api.get("/events").then(r => setList(r.data)).catch(() => {});
  useEffect(() => { load(); }, []);

  const save = async (e) => {
    e.preventDefault();
    try {
      if (editing) await api.put(`/events/${editing}`, form);
      else await api.post("/events", form);
      toast.success("Evento salvo.");
      setForm({ title: "", description: "", category: "gira", date: "", time: "" });
      setEditing(null); load();
    } catch (err) { toast.error(err?.response?.data?.detail || "Erro"); }
  };
  const startEdit = (e) => { setEditing(e.id); setForm({ title: e.title, description: e.description || "", category: e.category, date: e.date, time: e.time || "" }); };
  const del = async (e) => { if (!window.confirm("Remover evento?")) return; await api.delete(`/events/${e.id}`); load(); };

  return (
    <div className="grid lg:grid-cols-[380px,1fr] gap-6">
      <form onSubmit={save} className="parchment-card rounded-2xl p-6 space-y-3 h-fit" data-testid="event-form">
        <h3 className="font-display text-2xl text-terreiro-navy-deep">{editing ? "Editar evento" : "Novo evento"}</h3>
        <Field label="Título"><input required value={form.title} onChange={e => setForm(f => ({ ...f, title: e.target.value }))} className={inputCls} data-testid="event-title" /></Field>
        <Field label="Categoria">
          <select value={form.category} onChange={e => setForm(f => ({ ...f, category: e.target.value }))} className={inputCls} data-testid="event-category">
            {EVENT_CATEGORIES.map(c => <option key={c.value} value={c.value}>{c.label}</option>)}
          </select>
        </Field>
        <div className="grid grid-cols-2 gap-2">
          <Field label="Data"><input required type="date" value={form.date} onChange={e => setForm(f => ({ ...f, date: e.target.value }))} className={inputCls} data-testid="event-date" /></Field>
          <Field label="Hora"><input type="time" value={form.time} onChange={e => setForm(f => ({ ...f, time: e.target.value }))} className={inputCls} /></Field>
        </div>
        <Field label="Descrição"><textarea value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))} className={inputCls + " h-24"} /></Field>
        <div className="flex gap-2">
          <button type="submit" data-testid="event-save" className="btn-gold h-10 px-5 rounded-full text-sm font-semibold flex-1">{editing ? "Salvar" : "Criar"}</button>
          {editing && <button type="button" onClick={() => { setEditing(null); setForm({ title: "", description: "", category: "gira", date: "", time: "" }); }} className="h-10 px-4 rounded-full text-sm border border-terreiro-gold/40">Cancelar</button>}
        </div>
      </form>
      <div className="parchment-card rounded-2xl p-4 sm:p-6 overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="text-left text-xs uppercase tracking-widest text-terreiro-navy/60">
              <th className="py-2 pr-4">Data</th><th className="py-2 pr-4">Título</th><th className="py-2 pr-4">Categoria</th><th className="py-2 pr-4"></th>
            </tr>
          </thead>
          <tbody>
            {list.map(e => (
              <tr key={e.id} className="border-t border-terreiro-gold/20">
                <td className="py-3 pr-4 whitespace-nowrap">{e.date.split('-').reverse().join('/')} {e.time}</td>
                <td className="py-3 pr-4 font-medium text-terreiro-navy-deep">{e.title}</td>
                <td className="py-3 pr-4 capitalize">{e.category}</td>
                <td className="py-3 pr-4 text-right">
                  <button onClick={() => startEdit(e)} className="p-1.5 rounded hover:bg-terreiro-gold/20 text-terreiro-navy"><Pencil size={14} /></button>
                  <button onClick={() => del(e)} className="p-1.5 rounded hover:bg-terreiro-terracotta/15 text-terreiro-terracotta"><Trash2 size={14} /></button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// ---------- Notices ----------
function NoticesTab() {
  const [list, setList] = useState([]);
  const [form, setForm] = useState({ title: "", body: "", priority: "info" });
  const [editing, setEditing] = useState(null);
  const load = () => api.get("/notices").then(r => setList(r.data)).catch(() => {});
  useEffect(() => { load(); }, []);
  const save = async (e) => {
    e.preventDefault();
    try {
      if (editing) await api.put(`/notices/${editing}`, form);
      else await api.post("/notices", form);
      toast.success("Aviso publicado.");
      setForm({ title: "", body: "", priority: "info" }); setEditing(null); load();
    } catch (err) { toast.error(err?.response?.data?.detail || "Erro"); }
  };
  const del = async (n) => { if (!window.confirm("Remover aviso?")) return; await api.delete(`/notices/${n.id}`); load(); };
  const startEdit = (n) => { setEditing(n.id); setForm({ title: n.title, body: n.body, priority: n.priority }); };

  return (
    <div className="grid lg:grid-cols-[380px,1fr] gap-6">
      <form onSubmit={save} className="parchment-card rounded-2xl p-6 space-y-3 h-fit" data-testid="notice-form">
        <h3 className="font-display text-2xl text-terreiro-navy-deep">{editing ? "Editar aviso" : "Novo aviso"}</h3>
        <Field label="Título"><input required value={form.title} onChange={e => setForm(f => ({ ...f, title: e.target.value }))} className={inputCls} data-testid="notice-title" /></Field>
        <Field label="Prioridade">
          <select value={form.priority} onChange={e => setForm(f => ({ ...f, priority: e.target.value }))} className={inputCls}>
            <option value="info">Informativo</option><option value="important">Importante</option><option value="urgent">Urgente</option>
          </select>
        </Field>
        <Field label="Mensagem"><textarea required value={form.body} onChange={e => setForm(f => ({ ...f, body: e.target.value }))} className={inputCls + " h-32"} data-testid="notice-body" /></Field>
        <div className="flex gap-2">
          <button type="submit" data-testid="notice-save" className="btn-gold h-10 px-5 rounded-full text-sm font-semibold flex-1">{editing ? "Salvar" : "Publicar"}</button>
          {editing && <button type="button" onClick={() => { setEditing(null); setForm({ title: "", body: "", priority: "info" }); }} className="h-10 px-4 rounded-full text-sm border border-terreiro-gold/40">Cancelar</button>}
        </div>
      </form>
      <div className="space-y-3">
        {list.map(n => (
          <div key={n.id} className="parchment-card rounded-2xl p-5">
            <div className="flex items-start justify-between gap-2">
              <div className="min-w-0">
                <div className="text-[10px] uppercase tracking-widest font-semibold text-terreiro-terracotta">{n.priority}</div>
                <div className="font-display text-xl text-terreiro-navy-deep">{n.title}</div>
                <div className="text-sm text-terreiro-navy/75 mt-1 whitespace-pre-wrap">{n.body}</div>
              </div>
              <div className="flex gap-1">
                <button onClick={() => startEdit(n)} className="p-1.5 rounded hover:bg-terreiro-gold/20 text-terreiro-navy"><Pencil size={14} /></button>
                <button onClick={() => del(n)} className="p-1.5 rounded hover:bg-terreiro-terracotta/15 text-terreiro-terracotta"><Trash2 size={14} /></button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ---------- Settings ----------
function SettingsTab() {
  const [s, setS] = useState(null);
  useEffect(() => { api.get("/settings").then(r => setS(r.data)); }, []);
  if (!s) return null;
  const save = async (e) => {
    e.preventDefault();
    try {
      await api.put("/settings", { house_name: s.house_name, house_short: s.house_short, founded_year: Number(s.founded_year), welcome_message: s.welcome_message, boleto_info: s.boleto_info });
      toast.success("Configurações salvas.");
    } catch (err) { toast.error(err?.response?.data?.detail || "Erro"); }
  };
  return (
    <form onSubmit={save} className="parchment-card rounded-2xl p-6 space-y-4 max-w-3xl" data-testid="settings-form">
      <h3 className="font-display text-2xl text-terreiro-navy-deep">Configurações da casa</h3>
      <p className="text-xs text-terreiro-navy/60">Dados de identidade e mensagens. Os dados de recebimento de Pix ficam na aba <b>Config. Pagamento</b>.</p>
      <div className="grid sm:grid-cols-2 gap-3">
        <Field label="Nome da casa"><input value={s.house_name || ""} onChange={e => setS({ ...s, house_name: e.target.value })} className={inputCls} /></Field>
        <Field label="Sigla"><input value={s.house_short || ""} onChange={e => setS({ ...s, house_short: e.target.value })} className={inputCls} /></Field>
        <Field label="Ano de fundação"><input type="number" value={s.founded_year || ""} onChange={e => setS({ ...s, founded_year: e.target.value })} className={inputCls} /></Field>
      </div>
      <Field label="Boleto / instruções"><textarea value={s.boleto_info || ""} onChange={e => setS({ ...s, boleto_info: e.target.value })} className={inputCls + " h-24"} /></Field>
      <Field label="Mensagem de boas-vindas"><textarea value={s.welcome_message || ""} onChange={e => setS({ ...s, welcome_message: e.target.value })} className={inputCls + " h-32"} /></Field>
      <button type="submit" data-testid="settings-save" className="btn-gold h-10 px-6 rounded-full text-sm font-semibold">Salvar configurações</button>
    </form>
  );
}

// ---------- Payment Config (Pix) ----------
function PaymentConfigTab() {
  const [s, setS] = useState(null);
  useEffect(() => { api.get("/settings").then(r => setS(r.data)); }, []);
  if (!s) return null;
  const save = async (e) => {
    e.preventDefault();
    try {
      await api.put("/settings", {
        monthly_amount: Number(s.monthly_amount || 0),
        pix_bank: s.pix_bank || "",
        pix_holder_name: s.pix_holder_name || "",
        pix_key: s.pix_key || "",
        pix_code: s.pix_code || "",
        pix_qr_image: s.pix_qr_image || "",
      });
      toast.success("Dados de pagamento salvos.");
    } catch (err) { toast.error(err?.response?.data?.detail || "Erro"); }
  };
  const autoQr = s.pix_code
    ? `https://api.qrserver.com/v1/create-qr-code/?size=260x260&margin=8&data=${encodeURIComponent(s.pix_code)}`
    : "";
  const shownQr = s.pix_qr_image || autoQr;
  return (
    <form onSubmit={save} className="grid lg:grid-cols-[1fr,320px] gap-6 max-w-5xl" data-testid="payment-config-form">
      <div className="parchment-card rounded-2xl p-6 space-y-4">
        <div>
          <h3 className="font-display text-2xl text-terreiro-navy-deep">Configurações de Pagamento</h3>
          <p className="text-xs text-terreiro-navy/60 mt-1">Estes dados são exibidos aos associados na tela de contribuição. Alterando aqui, o Pix passa a ser direcionado para a nova conta imediatamente — sem precisar mexer no código.</p>
        </div>
        <div className="grid sm:grid-cols-2 gap-3">
          <Field label="Banco"><input value={s.pix_bank || ""} onChange={e => setS({ ...s, pix_bank: e.target.value })} className={inputCls} placeholder="Ex: Nubank, Caixa, Itaú..." data-testid="pc-bank" /></Field>
          <Field label="Nome do titular da conta"><input value={s.pix_holder_name || ""} onChange={e => setS({ ...s, pix_holder_name: e.target.value })} className={inputCls} placeholder="Nome completo do recebedor" data-testid="pc-holder" /></Field>
          <Field label="Chave Pix"><input value={s.pix_key || ""} onChange={e => setS({ ...s, pix_key: e.target.value })} className={inputCls} placeholder="CPF, e-mail, telefone ou aleatória" data-testid="pc-key" /></Field>
          <Field label="Valor padrão da mensalidade (R$)"><input type="number" step="0.01" min="0" value={s.monthly_amount || ""} onChange={e => setS({ ...s, monthly_amount: e.target.value })} className={inputCls} data-testid="pc-amount" /></Field>
        </div>
        <Field label="Pix Copia e Cola (opcional — se preenchido, o QR é gerado automaticamente a partir dele)">
          <textarea value={s.pix_code || ""} onChange={e => setS({ ...s, pix_code: e.target.value })} className={inputCls + " h-24 font-mono text-xs"} placeholder="Cole aqui o código Pix Copia e Cola" data-testid="pc-code" />
        </Field>
        <div>
          <label className="block text-xs uppercase tracking-widest text-terreiro-navy/70 mb-1.5">QR Code Pix (opcional — envie uma imagem para substituir o QR automático)</label>
          <PhotoPicker value={s.pix_qr_image} onChange={(v) => setS({ ...s, pix_qr_image: v })} label="" />
        </div>
        <button type="submit" data-testid="pc-save" className="btn-gold h-10 px-6 rounded-full text-sm font-semibold">Salvar dados de pagamento</button>
      </div>
      <aside className="parchment-card rounded-2xl p-6 h-fit">
        <div className="text-[10px] uppercase tracking-widest text-terreiro-terracotta font-semibold">Prévia do recebedor</div>
        <div className="mt-3 space-y-1 text-sm">
          <div className="text-terreiro-navy/60 text-xs uppercase tracking-widest">Banco</div>
          <div className="text-terreiro-navy-deep font-semibold">{s.pix_bank || "—"}</div>
          <div className="text-terreiro-navy/60 text-xs uppercase tracking-widest mt-3">Titular</div>
          <div className="text-terreiro-navy-deep font-semibold">{s.pix_holder_name || "—"}</div>
          <div className="text-terreiro-navy/60 text-xs uppercase tracking-widest mt-3">Chave</div>
          <div className="text-terreiro-navy-deep font-mono text-xs break-all">{s.pix_key || "—"}</div>
        </div>
        <div className="mt-4 flex justify-center">
          {shownQr ? (
            <img src={shownQr} alt="QR Code Pix" className="w-full max-w-[220px] rounded-lg border border-terreiro-gold/40 bg-white p-2" />
          ) : (
            <div className="w-full aspect-square rounded-lg border border-dashed border-terreiro-gold/40 flex items-center justify-center text-xs text-terreiro-navy/60 bg-terreiro-ivory text-center px-4">
              QR aparecerá aqui após configurar o Pix Copia e Cola ou enviar imagem
            </div>
          )}
        </div>
      </aside>
    </form>
  );
}

// ---------- Reports ----------
function ReportsTab() {
  const now = new Date();
  const [year, setYear] = useState(now.getFullYear());
  const [month, setMonth] = useState(now.getMonth() + 1);
  const [data, setData] = useState(null);
  useEffect(() => {
    api.get(`/reports/summary?year=${year}&month=${month}`).then(r => setData(r.data));
  }, [year, month]);
  return (
    <div className="space-y-6">
      <div className="parchment-card rounded-2xl p-6 flex flex-wrap gap-4 items-end">
        <Field label="Mês"><select value={month} onChange={e => setMonth(Number(e.target.value))} className={inputCls}>{MONTHS_PT.map((m,i)=><option key={i} value={i+1}>{m}</option>)}</select></Field>
        <Field label="Ano"><input type="number" value={year} onChange={e => setYear(Number(e.target.value))} className={inputCls} /></Field>
      </div>
      {data && (
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <Stat label="Membros" value={data.total_members} />
          <Stat label="Em dia" value={data.paid_count} accent="#4A5D3A" />
          <Stat label="Pendentes" value={data.pending_count} accent="#B4593A" />
          <Stat label="Arrecadado" value={currencyBRL(data.total_paid)} accent="#C8A85A" />
          <Stat label="Esperado" value={currencyBRL(data.expected)} />
          <Stat label="% arrecadado" value={data.expected ? `${Math.round((data.total_paid / data.expected) * 100)}%` : "0%"} accent="#1B3A5B" />
        </div>
      )}
    </div>
  );
}

function Stat({ label, value, accent = "#1B3A5B" }) {
  return (
    <div className="parchment-card rounded-2xl p-5">
      <div className="text-[10px] uppercase tracking-widest" style={{ color: accent }}>{label}</div>
      <div className="font-display text-3xl text-terreiro-navy-deep mt-1">{value}</div>
    </div>
  );
}

const inputCls = "w-full h-10 px-3 rounded-lg bg-terreiro-ivory border border-terreiro-gold/40 outline-none focus:border-terreiro-gold focus:ring-2 focus:ring-terreiro-gold/30 text-terreiro-navy-deep text-sm";
function Field({ label, children }) {
  return (
    <div className="min-w-0 flex-1">
      <label className="block text-xs uppercase tracking-widest text-terreiro-navy/70 mb-1.5">{label}</label>
      {children}
    </div>
  );
}
