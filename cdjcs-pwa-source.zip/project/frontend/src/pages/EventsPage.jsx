import React, { useEffect, useMemo, useState } from "react";
import { api, EVENT_CATEGORIES, MONTHS_PT } from "../lib/api";
import { ChevronLeft, ChevronRight, Calendar as CalIcon } from "lucide-react";

function startOfMonth(y, m) { return new Date(y, m, 1); }
function daysInMonth(y, m) { return new Date(y, m + 1, 0).getDate(); }

export default function EventsPage() {
  const today = new Date();
  const [cursor, setCursor] = useState({ y: today.getFullYear(), m: today.getMonth() });
  const [events, setEvents] = useState([]);
  const [selected, setSelected] = useState(null);

  useEffect(() => {
    api.get(`/events?year=${cursor.y}&month=${cursor.m + 1}`)
      .then(r => setEvents(r.data)).catch(() => {});
  }, [cursor]);

  const grid = useMemo(() => {
    const first = startOfMonth(cursor.y, cursor.m);
    const startDow = first.getDay(); // 0 sun
    const total = daysInMonth(cursor.y, cursor.m);
    const cells = [];
    for (let i = 0; i < startDow; i++) cells.push(null);
    for (let d = 1; d <= total; d++) cells.push(d);
    while (cells.length % 7 !== 0) cells.push(null);
    return cells;
  }, [cursor]);

  const eventsByDay = useMemo(() => {
    const map = {};
    for (const e of events) {
      const d = parseInt(e.date.slice(8, 10), 10);
      if (!map[d]) map[d] = [];
      map[d].push(e);
    }
    return map;
  }, [events]);

  const prev = () => setCursor(c => {
    const d = new Date(c.y, c.m - 1, 1);
    return { y: d.getFullYear(), m: d.getMonth() };
  });
  const next = () => setCursor(c => {
    const d = new Date(c.y, c.m + 1, 1);
    return { y: d.getFullYear(), m: d.getMonth() };
  });

  const catMeta = (v) => EVENT_CATEGORIES.find(c => c.value === v) || { label: v, color: "#1B3A5B" };

  return (
    <div className="max-w-7xl mx-auto px-4 md:px-6 py-8 md:py-12" data-testid="events-page">
      <div className="animate-fade-in flex flex-col md:flex-row md:items-end md:justify-between gap-4">
        <div>
          <div className="text-[11px] tracking-[0.3em] uppercase text-terreiro-terracotta font-semibold">Agenda</div>
          <h1 className="font-display text-4xl sm:text-5xl text-terreiro-navy-deep mt-2">Nossos Eventos</h1>
          <p className="text-terreiro-navy/70 mt-2 max-w-2xl">
            Reuniões, giras, estudos, festividades e mutirões da nossa casa.
          </p>
        </div>
        <div className="flex items-center gap-3">
          <button onClick={prev} data-testid="cal-prev" className="w-10 h-10 rounded-full border border-terreiro-gold/40 hover:bg-terreiro-gold/15 flex items-center justify-center text-terreiro-navy-deep">
            <ChevronLeft size={18} />
          </button>
          <div className="font-display text-2xl text-terreiro-navy-deep min-w-[10rem] text-center" data-testid="cal-month">
            {MONTHS_PT[cursor.m]} <span className="text-terreiro-gold">{cursor.y}</span>
          </div>
          <button onClick={next} data-testid="cal-next" className="w-10 h-10 rounded-full border border-terreiro-gold/40 hover:bg-terreiro-gold/15 flex items-center justify-center text-terreiro-navy-deep">
            <ChevronRight size={18} />
          </button>
        </div>
      </div>

      <div className="mt-6 flex flex-wrap gap-2">
        {EVENT_CATEGORIES.map(c => (
          <div key={c.value} className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs bg-terreiro-cream border border-terreiro-gold/30">
            <span className="w-2 h-2 rounded-full" style={{ background: c.color }} />
            <span className="text-terreiro-navy-deep">{c.label}</span>
          </div>
        ))}
      </div>

      <div className="mt-6 grid lg:grid-cols-[1fr,320px] gap-6">
        <div className="parchment-card rounded-2xl p-4 sm:p-6 animate-fade-in">
          <div className="grid grid-cols-7 text-center text-[10px] uppercase tracking-widest text-terreiro-navy/60 mb-2">
            {["Dom","Seg","Ter","Qua","Qui","Sex","Sáb"].map(d => <div key={d} className="py-1">{d}</div>)}
          </div>
          <div className="grid grid-cols-7 gap-1.5">
            {grid.map((d, i) => {
              const list = d ? eventsByDay[d] || [] : [];
              const isToday = d && cursor.y === today.getFullYear() && cursor.m === today.getMonth() && d === today.getDate();
              const isSel = selected && selected.day === d;
              return (
                <button
                  key={i}
                  disabled={!d}
                  onClick={() => setSelected(d ? { day: d, list } : null)}
                  data-testid={d ? `cal-day-${d}` : undefined}
                  className={`min-h-[74px] sm:min-h-[92px] rounded-lg border p-2 text-left transition-all
                    ${!d ? 'invisible' : ''}
                    ${isToday ? 'border-terreiro-gold bg-terreiro-gold/10' : 'border-terreiro-gold/25 bg-terreiro-ivory/60'}
                    ${isSel ? 'ring-2 ring-terreiro-navy' : ''}
                    hover:bg-terreiro-gold/15`}
                >
                  <div className={`text-sm font-semibold ${isToday ? 'text-terreiro-terracotta' : 'text-terreiro-navy-deep'}`}>
                    {d}
                  </div>
                  <div className="mt-1 space-y-1">
                    {list.slice(0, 2).map(e => (
                      <div key={e.id} className="text-[10px] px-1.5 py-0.5 rounded truncate"
                           style={{ background: `${catMeta(e.category).color}22`, color: catMeta(e.category).color }}>
                        {e.title}
                      </div>
                    ))}
                    {list.length > 2 && <div className="text-[10px] text-terreiro-navy/60">+{list.length - 2}</div>}
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        <aside className="parchment-card rounded-2xl p-6 h-fit animate-fade-in" style={{ animationDelay: "0.1s" }}>
          <div className="flex items-center gap-2 text-terreiro-navy-deep">
            <CalIcon size={18} className="text-terreiro-olive" />
            <h3 className="font-display text-2xl">
              {selected ? `Dia ${selected.day}` : "Eventos do mês"}
            </h3>
          </div>
          <div className="mt-4 space-y-3">
            {(selected ? selected.list : events).length === 0 && (
              <p className="text-sm text-terreiro-navy/60">Nenhum evento.</p>
            )}
            {(selected ? selected.list : events).map(e => {
              const c = catMeta(e.category);
              return (
                <div key={e.id} className="p-3 rounded-lg bg-terreiro-ivory/70 border border-terreiro-gold/25">
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full" style={{ background: c.color }} />
                    <div className="text-[10px] uppercase tracking-widest font-semibold" style={{ color: c.color }}>
                      {c.label}
                    </div>
                    <div className="ml-auto text-xs text-terreiro-navy/60">
                      {e.date.slice(8, 10)}/{e.date.slice(5, 7)} {e.time && `· ${e.time}`}
                    </div>
                  </div>
                  <div className="mt-1 font-semibold text-terreiro-navy-deep">{e.title}</div>
                  {e.description && <div className="text-xs text-terreiro-navy/70 mt-1">{e.description}</div>}
                </div>
              );
            })}
          </div>
        </aside>
      </div>
    </div>
  );
}
