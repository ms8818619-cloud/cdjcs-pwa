import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { toast } from "sonner";
import { Download, Check } from "lucide-react";
import { useAuth } from "../lib/auth";
import { maskCPFInput } from "../lib/api";
import Brasao from "../components/Brasao";
import useInstallPrompt from "../hooks/useInstallPrompt";

export default function LoginPage() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const [cpf, setCpf] = useState("");
  const [loading, setLoading] = useState(false);
  const { canInstall, isInstalled, isIos, promptInstall } = useInstallPrompt();

  const handleInstallClick = async () => {
    if (canInstall) {
      const choice = await promptInstall();
      if (choice.outcome === "accepted") {
        toast.success("Aplicativo instalado com sucesso!");
      }
      return;
    }
    if (isIos) {
      toast.info(
        "Para instalar: toque em Compartilhar e depois em \"Adicionar à Tela de Início\".",
        { duration: 6000 }
      );
      return;
    }
    toast.info(
      "Seu navegador ainda não liberou a instalação. Procure a opção \"Instalar aplicativo\" no menu do navegador.",
      { duration: 6000 }
    );
  };

  const submit = async (e) => {
    e.preventDefault();
    const digits = cpf.replace(/\D/g, "");
    if (digits.length !== 11) {
      toast.error("Informe um CPF válido de 11 dígitos");
      return;
    }
    setLoading(true);
    try {
      await login(digits);
      navigate("/bem-vindo");
    } catch (err) {
      toast.error(err?.response?.data?.detail || "Falha ao entrar");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen relative overflow-hidden flex items-center">
      {/* Decorative background */}
      <div className="absolute inset-0 -z-10">
        <div className="absolute inset-0 bg-gradient-to-br from-terreiro-parchment via-terreiro-cream to-terreiro-parchment" />
        <div
          className="absolute -top-40 -left-40 w-[520px] h-[520px] rounded-full opacity-40 blur-3xl"
          style={{ background: "radial-gradient(circle, rgba(200,168,90,0.45), transparent 65%)" }}
        />
        <div
          className="absolute -bottom-40 -right-40 w-[520px] h-[520px] rounded-full opacity-40 blur-3xl"
          style={{ background: "radial-gradient(circle, rgba(27,58,91,0.4), transparent 65%)" }}
        />
      </div>

      <div className="w-full max-w-6xl mx-auto px-6 py-12 grid lg:grid-cols-2 gap-12 items-center">
        {/* Left side - identity */}
        <div className="flex flex-col items-center lg:items-start text-center lg:text-left animate-fade-in">
          <Brasao size={220} />
          <div className="mt-8">
            <div className="text-[11px] tracking-[0.35em] uppercase text-terreiro-terracotta font-semibold">
              Fundado em 2022 · C.D.J.C.S
            </div>
            <h1 className="mt-3 font-display text-4xl sm:text-5xl lg:text-6xl text-terreiro-navy-deep leading-[1.05]">
              Casa de Jurema
              <br />
              <span className="brasao-gold-text">Caboclo Samambaia</span>
            </h1>
            <div className="gold-divider my-6 max-w-md" />
            <p className="text-terreiro-navy/80 max-w-lg leading-relaxed">
              Um lar de fé, união e espiritualidade. Este espaço é dedicado ao
              cuidado da nossa casa: acompanhe sua contribuição, agenda de
              giras, estudos e avisos importantes.
            </p>

            {!isInstalled && (
              <button
                type="button"
                onClick={handleInstallClick}
                data-testid="install-app-btn"
                className="btn-outline-navy mt-6 inline-flex items-center gap-2 px-5 h-10 rounded-full text-xs font-semibold tracking-wide uppercase"
              >
                <Download size={14} strokeWidth={2.2} />
                Instalar aplicativo
              </button>
            )}
            {isInstalled && (
              <div className="mt-6 inline-flex items-center gap-2 px-5 h-10 rounded-full text-xs font-semibold tracking-wide uppercase text-terreiro-olive/80">
                <Check size={14} strokeWidth={2.2} />
                Aplicativo instalado
              </div>
            )}
          </div>
        </div>

        {/* Right side - login card */}
        <div className="animate-fade-in" style={{ animationDelay: "0.15s" }}>
          <div className="parchment-card rounded-2xl p-8 sm:p-10 max-w-md mx-auto">
            <div className="text-center">
              <div className="text-[11px] tracking-[0.3em] uppercase text-terreiro-gold font-semibold">
                Acesso do Membro
              </div>
              <h2 className="font-display text-3xl text-terreiro-navy-deep mt-2">
                Entrar na Casa
              </h2>
              <p className="text-sm text-terreiro-navy/70 mt-2">
                Utilize o CPF cadastrado pelo administrador.
              </p>
            </div>

            <form onSubmit={submit} className="mt-8 space-y-5" data-testid="login-form">
              <div>
                <label className="block text-xs uppercase tracking-widest text-terreiro-navy/70 mb-2">
                  CPF
                </label>
                <input
                  data-testid="login-cpf-input"
                  type="text"
                  inputMode="numeric"
                  autoComplete="off"
                  value={cpf}
                  onChange={(e) => setCpf(maskCPFInput(e.target.value))}
                  placeholder="000.000.000-00"
                  className="w-full h-12 px-4 rounded-lg bg-terreiro-ivory border border-terreiro-gold/40 outline-none focus:border-terreiro-gold focus:ring-2 focus:ring-terreiro-gold/30 text-terreiro-navy-deep text-lg tracking-wider"
                />
              </div>
              <button
                type="submit"
                disabled={loading}
                data-testid="login-submit-btn"
                className="btn-gold w-full h-12 rounded-lg font-semibold text-base tracking-wide disabled:opacity-60"
              >
                {loading ? "Entrando..." : "Entrar"}
              </button>
            </form>

            <div className="gold-divider my-6" />
            <p className="text-xs text-terreiro-navy/60 text-center">
              O acesso é liberado apenas para membros previamente cadastrados.
              <br />Em caso de dúvida, procure o administrador da casa.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
