import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { api, currencyBRL, MONTHS_PT } from "../lib/api";
import { useAuth } from "../lib/auth";
import { CheckCircle2, AlertTriangle, Calendar, Bell, ArrowRight, Sparkles } from "lucide-react";

export default function DashboardPage() {
  const { user } = useAuth();
  const [status, setStatus] = useState(null);
  const [events, setEvents] = useState([]);
  const [notices, setNotices] = useState([]);

  useEffect(() => {
    api.get("/payments/me/status").then(r => setStatus(r.data)).catch(() => {});
    const now = new Date();
    api.get(`/events?year=${now.getFullYear()}&month=${now.getMonth() + 1}`).then(r => setEvents(r.data)).catch(() => {});
    api.get("/notices").then(r => setNotices(r.data.slice(0, 3))).catch(() => {});
  }, []);

  const now = new Date();
  const monthLabel = MONTHS_PT[now.getMonth()];
  const emDia = status?.status === "em_dia";

  const upcoming = events
    .filter(e => e.date >= now.toISOString().slice(0, 10))
    .slice(0, 4);

  return (
    <div className="max-w-7xl mx-auto px-4 md:px-6 py-8 md:py-12" data-testid="dashboard">
      <div className="animate-fade-in">
        <div className="text-[11px] tracking-[0.3em] uppercase text-terreiro-terracotta font-semibold">
          Painel do Membro
        </div>
        <h1 className="font-display text-4xl sm:text-5xl text-terreiro-navy-deep mt-2">
          Olá, {user?.name?.split(" ")[0]}.
        </h1>
        <p className="text-terreiro-navy/70 mt-2 max-w-2xl">
          Que a paz esteja com você. Aqui está um resumo da sua contribuição, próximos
          eventos e avisos da casa.
        </p>
      </div>

      <div className="mt-10 grid gap-6 lg:grid-cols-3">
        {/* Status card */}
        <div className="lg:col-span-2 navy-card rounded-2xl p-7 relative overflow-hidden animate-fade-in">
          <div className="absolute -right-12 -top-12 w-56 h-56 rounded-full opacity-20"
               style={{ background: "radial-gradient(circle, #E4C97A, transparent 70%)" }} />
          <div className="flex items-start justify-between gap-4">
            <div>
              <div className="text-[11px] tracking-[0.3em] uppercase text-terreiro-gold-soft/90">
                Contribuição de {monthLabel}
              </div>
              <div className="mt-2 flex items-baseline gap-2">
                <div className="font-display text-5xl text-terreiro-cream" data-testid="dashboard-amount">
                  {currencyBRL(status?.amount || 0)}
                </div>
              </div>
              <div className="mt-4 inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full border"
                   style={{
                     borderColor: emDia ? "rgba(200,168,90,0.6)" : "rgba(180,89,58,0.7)",
                     background: emDia ? "rgba(200,168,90,0.15)" : "rgba(180,89,58,0.15)",
                   }}
                   data-testid="dashboard-status-badge">
                {emDia ? <CheckCircle2 size={16} className="text-terreiro-gold-soft" /> : <AlertTriangle size={16} className="text-terreiro-terracotta" />}
                <span className="text-xs uppercase tracking-widest font-semibold">
                  {emDia ? "Em dia" : "Em atraso"}
                </span>
              </div>
            </div>
            <Sparkles className="text-terreiro-gold-soft/70" size={32} />
          </div>
          <div className="mt-8">
            <Link
              to="/app/contribuicao"
              data-testid="dashboard-to-payment-btn"
              className="btn-gold inline-flex items-center gap-2 h-11 px-5 rounded-full text-sm font-semibold"
            >
              Ver contribuição <ArrowRight size={16} />
            </Link>
          </div>
        </div>

        {/* Notices quick */}
        <div className="parchment-card rounded-2xl p-6 animate-fade-in" style={{ animationDelay: "0.1s" }}>
          <div className="flex items-center gap-2 text-terreiro-navy-deep">
            <Bell size={18} className="text-terreiro-terracotta" />
            <h3 className="font-display text-2xl">Últimos avisos</h3>
          </div>
          <div className="mt-4 space-y-3">
            {notices.length === 0 && (
              <p className="text-sm text-terreiro-navy/60">Nenhum aviso no momento.</p>
            )}
            {notices.map(n => (
              <div key={n.id} className="border-l-2 pl-3 py-1"
                   style={{ borderColor: n.priority === 'urgent' ? '#B4593A' : n.priority === 'important' ? '#C8A85A' : '#1B3A5B' }}>
                <div className="text-sm font-semibold text-terreiro-navy-deep line-clamp-1">{n.title}</div>
                <div className="text-xs text-terreiro-navy/70 line-clamp-2">{n.body}</div>
              </div>
            ))}
          </div>
          <Link to="/app/avisos" className="mt-4 inline-flex items-center gap-1 text-xs uppercase tracking-widest text-terreiro-navy hover:text-terreiro-terracotta">
            Ver todos <ArrowRight size={12} />
          </Link>
        </div>

        {/* Events */}
        <div className="lg:col-span-3 parchment-card rounded-2xl p-6 animate-fade-in" style={{ animationDelay: "0.15s" }}>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-terreiro-navy-deep">
              <Calendar size={18} className="text-terreiro-olive" />
              <h3 className="font-display text-2xl">Próximos eventos</h3>
            </div>
            <Link to="/app/eventos" className="text-xs uppercase tracking-widest text-terreiro-navy hover:text-terreiro-terracotta">
              Ver calendário
            </Link>
          </div>
          <div className="mt-4 grid sm:grid-cols-2 lg:grid-cols-4 gap-3">
            {upcoming.length === 0 && (
              <p className="text-sm text-terreiro-navy/60 col-span-full">Sem eventos programados nos próximos dias.</p>
            )}
            {upcoming.map(e => {
              const d = new Date(e.date + "T00:00:00");
              return (
                <div key={e.id} className="rounded-xl p-4 bg-terreiro-ivory/70 border border-terreiro-gold/25">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 rounded-lg flex flex-col items-center justify-center bg-terreiro-navy text-terreiro-cream">
                      <div className="text-[10px] uppercase tracking-widest">{MONTHS_PT[d.getMonth()].slice(0,3)}</div>
                      <div className="font-display text-lg leading-none">{String(d.getDate()).padStart(2,'0')}</div>
                    </div>
                    <div className="min-w-0">
                      <div className="text-[10px] uppercase tracking-widest text-terreiro-terracotta font-semibold">{e.category}</div>
                      <div className="font-semibold text-terreiro-navy-deep line-clamp-1">{e.title}</div>
                      {e.time && <div className="text-xs text-terreiro-navy/60">{e.time}</div>}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
