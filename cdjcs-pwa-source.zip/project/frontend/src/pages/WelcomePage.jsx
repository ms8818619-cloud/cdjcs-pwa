import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import Brasao from "../components/Brasao";
import { useAuth } from "../lib/auth";
import { api } from "../lib/api";

export default function WelcomePage() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [msg, setMsg] = useState("");
  const [houseName, setHouseName] = useState("Casa de Jurema Caboclo Samambaia");
  const [countdown, setCountdown] = useState(6);

  useEffect(() => {
    api.get("/settings").then((r) => {
      setMsg(r.data?.welcome_message || "");
      setHouseName(r.data?.house_name || houseName);
    }).catch(() => {});
  }, []); // eslint-disable-line

  useEffect(() => {
    const iv = setInterval(() => setCountdown((c) => c - 1), 1000);
    const t = setTimeout(() => navigate("/app"), 6000);
    return () => { clearInterval(iv); clearTimeout(t); };
  }, [navigate]);

  return (
    <div className="min-h-screen relative flex items-center justify-center overflow-hidden">
      <div className="absolute inset-0 -z-10">
        <div className="absolute inset-0" style={{
          background: "radial-gradient(circle at 50% 30%, #1B3A5B 0%, #132A44 60%, #0c1d33 100%)"
        }} />
        <div className="absolute inset-0 opacity-30" style={{
          background: "radial-gradient(circle at 20% 80%, rgba(200,168,90,0.35), transparent 45%), radial-gradient(circle at 80% 20%, rgba(180,89,58,0.25), transparent 45%)"
        }} />
      </div>

      <div className="max-w-3xl mx-auto px-6 py-16 text-center text-terreiro-cream animate-fade-in-slow">
        <div className="flex justify-center">
          <Brasao size={180} />
        </div>
        <div className="mt-8 text-[11px] tracking-[0.35em] uppercase text-terreiro-gold-soft/90">
          Boas-vindas, {user?.name?.split(" ")[0] || "irmão(ã)"}
        </div>
        <h1 className="mt-4 font-display text-4xl sm:text-5xl lg:text-6xl leading-tight" data-testid="welcome-title">
          Salve, <span className="brasao-gold-text">a Casa te acolhe</span>
        </h1>
        <div className="gold-divider my-8 mx-auto max-w-md opacity-80" />
        <p className="max-w-2xl mx-auto text-base sm:text-lg text-terreiro-cream/85 leading-relaxed" data-testid="welcome-message">
          {msg}
        </p>
        <div className="mt-10 text-xs uppercase tracking-[0.3em] text-terreiro-gold-soft/70">
          Entrando em {countdown > 0 ? countdown : 0}...
        </div>
        <button
          onClick={() => navigate("/app")}
          data-testid="welcome-continue-btn"
          className="btn-gold mt-6 px-8 h-11 rounded-full text-sm font-semibold"
        >
          Entrar agora
        </button>
      </div>
    </div>
  );
}
