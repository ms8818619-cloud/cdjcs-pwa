import React, { useEffect, useState } from "react";
import { api } from "../lib/api";
import { Bell, AlertCircle, Megaphone } from "lucide-react";

const PRIORITY_META = {
  info: { label: "Informativo", color: "#1B3A5B", Icon: Bell },
  important: { label: "Importante", color: "#C8A85A", Icon: Megaphone },
  urgent: { label: "Urgente", color: "#B4593A", Icon: AlertCircle },
};

export default function NoticesPage() {
  const [notices, setNotices] = useState([]);
  useEffect(() => {
    api.get("/notices").then(r => setNotices(r.data)).catch(() => {});
  }, []);

  return (
    <div className="max-w-4xl mx-auto px-4 md:px-6 py-8 md:py-12" data-testid="notices-page">
      <div className="animate-fade-in">
        <div className="text-[11px] tracking-[0.3em] uppercase text-terreiro-terracotta font-semibold">Comunicados</div>
        <h1 className="font-display text-4xl sm:text-5xl text-terreiro-navy-deep mt-2">Avisos da Casa</h1>
        <p className="text-terreiro-navy/70 mt-2">
          Mensagens e comunicados publicados pelo administrador.
        </p>
      </div>
      <div className="mt-8 space-y-4">
        {notices.length === 0 && (
          <div className="parchment-card rounded-2xl p-8 text-center text-terreiro-navy/60">
            Nenhum aviso publicado.
          </div>
        )}
        {notices.map(n => {
          const p = PRIORITY_META[n.priority] || PRIORITY_META.info;
          const Icon = p.Icon;
          return (
            <article key={n.id} className="parchment-card rounded-2xl p-6 animate-fade-in" data-testid={`notice-${n.id}`}>
              <div className="flex items-center gap-2">
                <div className="w-9 h-9 rounded-full flex items-center justify-center" style={{ background: `${p.color}22`, color: p.color }}>
                  <Icon size={16} />
                </div>
                <div className="text-[10px] uppercase tracking-widest font-semibold" style={{ color: p.color }}>{p.label}</div>
                <div className="ml-auto text-xs text-terreiro-navy/60">
                  {new Date(n.created_at).toLocaleDateString('pt-BR', { day: '2-digit', month: 'short', year: 'numeric' })}
                </div>
              </div>
              <h2 className="mt-3 font-display text-2xl text-terreiro-navy-deep">{n.title}</h2>
              <p className="mt-2 text-terreiro-navy/80 whitespace-pre-wrap leading-relaxed">{n.body}</p>
              {n.created_by_name && (
                <div className="mt-4 text-xs text-terreiro-navy/50">— {n.created_by_name}</div>
              )}
            </article>
          );
        })}
      </div>
    </div>
  );
}
