import { useEffect, useState, useCallback } from "react";

function isStandaloneMode() {
  return (
    window.matchMedia?.("(display-mode: standalone)")?.matches ||
    window.navigator.standalone === true
  );
}

function isIosDevice() {
  return /iphone|ipad|ipod/i.test(window.navigator.userAgent);
}

/**
 * Hook para controlar o prompt de instalação do PWA ("Instalar aplicativo").
 *
 * - Android/Chrome/Edge: captura o evento `beforeinstallprompt` e permite
 *   disparar a instalação nativa através de `promptInstall()`.
 * - iOS/Safari: não existe evento de instalação programática, então
 *   sinalizamos `isIos` para exibirmos instruções manuais
 *   ("Compartilhar" → "Adicionar à Tela de Início").
 * - Se o app já estiver instalado (rodando em modo standalone), `isInstalled`
 *   fica true e o botão pode ser ocultado.
 */
export default function useInstallPrompt() {
  const [deferredPrompt, setDeferredPrompt] = useState(null);
  const [isInstalled, setIsInstalled] = useState(isStandaloneMode());
  const [isIos] = useState(isIosDevice());

  useEffect(() => {
    const handleBeforeInstallPrompt = (event) => {
      event.preventDefault();
      setDeferredPrompt(event);
    };

    const handleAppInstalled = () => {
      setDeferredPrompt(null);
      setIsInstalled(true);
    };

    window.addEventListener("beforeinstallprompt", handleBeforeInstallPrompt);
    window.addEventListener("appinstalled", handleAppInstalled);

    return () => {
      window.removeEventListener("beforeinstallprompt", handleBeforeInstallPrompt);
      window.removeEventListener("appinstalled", handleAppInstalled);
    };
  }, []);

  const promptInstall = useCallback(async () => {
    if (!deferredPrompt) return { outcome: "unavailable" };
    deferredPrompt.prompt();
    const choice = await deferredPrompt.userChoice;
    if (choice.outcome === "accepted") {
      setIsInstalled(true);
    }
    setDeferredPrompt(null);
    return choice;
  }, [deferredPrompt]);

  const canInstall = Boolean(deferredPrompt) && !isInstalled;

  return { canInstall, isInstalled, isIos, promptInstall };
}
