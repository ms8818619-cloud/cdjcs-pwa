import React, { useState } from "react";
import { NavLink, Outlet, useNavigate } from "react-router-dom";
import Brasao from "./Brasao";
import { useAuth } from "../lib/auth";
import Avatar from "./Avatar";
import {
  Calendar, Bell, Wallet, ShieldCheck, LogOut, Home, Menu, X,
} from "lucide-react";
import { Button } from "./ui/button";

const NAV = [
  { to: "/app", label: "Início", icon: Home, testid: "nav-home", end: true },
  { to: "/app/contribuicao", label: "Contribuição", icon: Wallet, testid: "nav-contribuicao" },
  { to: "/app/eventos", label: "Nossos Eventos", icon: Calendar, testid: "nav-eventos" },
  { to: "/app/avisos", label: "Avisos", icon: Bell, testid: "nav-avisos" },
];

export default function Layout() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);

  const doLogout = () => { logout(); navigate("/"); };

  const nav = [...NAV];
  if (user?.is_admin) nav.push({ to: "/app/admin", label: "Painel do Admin", icon: ShieldCheck, testid: "nav-admin" });

  return (
    <div className="min-h-screen flex flex-col">
      <header className="sticky top-0 z-40 backdrop-blur bg-terreiro-cream/85 border-b border-terreiro-gold/30">
        <div className="max-w-7xl mx-auto px-4 md:px-6 h-20 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <Brasao size={52} glow={false} />
            <div className="leading-tight hidden sm:block">
              <div className="font-display text-lg md:text-xl text-terreiro-navy-deep font-semibold">
                Casa de Jurema
              </div>
              <div className="text-[11px] tracking-[0.25em] uppercase text-terreiro-navy/70">
                Caboclo Samambaia
              </div>
            </div>
          </div>

          <nav className="hidden lg:flex items-center gap-1">
            {nav.map(({ to, label, icon: Icon, testid, end }) => (
              <NavLink
                key={to}
                to={to}
                end={end}
                data-testid={testid}
                className={({ isActive }) =>
                  `flex items-center gap-2 px-3.5 py-2 rounded-full text-sm transition-all ${
                    isActive
                      ? "bg-terreiro-navy text-terreiro-cream shadow-md"
                      : "text-terreiro-navy-deep hover:bg-terreiro-gold/15"
                  }`
                }
              >
                <Icon size={16} />
                <span>{label}</span>
              </NavLink>
            ))}
          </nav>

          <div className="flex items-center gap-2">
            <div className="hidden md:flex flex-col items-end text-right">
              <span className="text-xs text-terreiro-navy/60 uppercase tracking-widest">
                {user?.is_admin ? "Administrador" : "Irmão(ã) de fé"}
              </span>
              <span className="text-sm font-semibold text-terreiro-navy-deep" data-testid="header-user-name">
                {user?.name}
              </span>
            </div>
            <Avatar photo={user?.photo} name={user?.name} size={40} />
            <Button
              variant="ghost"
              size="sm"
              onClick={doLogout}
              data-testid="btn-logout"
              className="text-terreiro-navy hover:text-terreiro-terracotta"
            >
              <LogOut size={16} className="mr-1" /> Sair
            </Button>
            <button
              className="lg:hidden p-2 rounded-full hover:bg-terreiro-gold/15 text-terreiro-navy-deep"
              onClick={() => setOpen(v => !v)}
              data-testid="btn-mobile-menu"
              aria-label="Menu"
            >
              {open ? <X size={22} /> : <Menu size={22} />}
            </button>
          </div>
        </div>
        {open && (
          <div className="lg:hidden border-t border-terreiro-gold/25 bg-terreiro-cream animate-fade-in">
            <div className="max-w-7xl mx-auto px-4 py-3 flex flex-col gap-1">
              {nav.map(({ to, label, icon: Icon, testid, end }) => (
                <NavLink
                  key={to}
                  to={to}
                  end={end}
                  onClick={() => setOpen(false)}
                  data-testid={`m-${testid}`}
                  className={({ isActive }) =>
                    `flex items-center gap-3 px-4 py-3 rounded-lg text-sm ${
                      isActive
                        ? "bg-terreiro-navy text-terreiro-cream"
                        : "text-terreiro-navy-deep hover:bg-terreiro-gold/15"
                    }`
                  }
                >
                  <Icon size={18} />
                  <span>{label}</span>
                </NavLink>
              ))}
            </div>
          </div>
        )}
      </header>

      <main className="flex-1">
        <Outlet />
      </main>

      <footer className="mt-auto border-t border-terreiro-gold/25 bg-terreiro-cream/80">
        <div className="max-w-7xl mx-auto px-6 py-6 flex flex-col md:flex-row items-center justify-between gap-2 text-xs text-terreiro-navy/70">
          <div className="font-display text-base text-terreiro-navy-deep">
            C.D.J.C.S <span className="opacity-60">— Fundado em 2022</span>
          </div>
          <div>Feito com fé, união e axé.</div>
        </div>
      </footer>
    </div>
  );
}
