import React from "react";
import { User } from "lucide-react";

/**
 * Avatar com foto ou iniciais elegantes.
 * size: em px. photo: data URL base64. name: para gerar iniciais.
 */
export default function Avatar({ photo, name, size = 40, className = "" }) {
  const initials = (name || "")
    .split(" ")
    .filter(Boolean)
    .slice(0, 2)
    .map(w => w[0]?.toUpperCase() || "")
    .join("");
  const style = { width: size, height: size };
  return (
    <div
      className={`rounded-full overflow-hidden border border-terreiro-gold/40 bg-terreiro-navy text-terreiro-cream flex items-center justify-center flex-shrink-0 ${className}`}
      style={style}
      data-testid="avatar"
    >
      {photo ? (
        <img src={photo} alt={name || "foto"} className="w-full h-full object-cover" />
      ) : initials ? (
        <span className="font-display" style={{ fontSize: size * 0.4 }}>{initials}</span>
      ) : (
        <User size={size * 0.5} />
      )}
    </div>
  );
}
