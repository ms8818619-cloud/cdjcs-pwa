import React, { useRef, useState } from "react";
import { Camera, Image as ImageIcon, X } from "lucide-react";
import { toast } from "sonner";

/**
 * Comprime uma imagem para ~400x400px, JPEG 80%, retornando data URL base64.
 * Mantém o tamanho no MongoDB pequeno (~30-60 KB por foto).
 */
async function resizeImage(file, maxSize = 400, quality = 0.8) {
  const dataUrl = await new Promise((res, rej) => {
    const r = new FileReader();
    r.onload = () => res(r.result);
    r.onerror = rej;
    r.readAsDataURL(file);
  });
  const img = await new Promise((res, rej) => {
    const i = new Image();
    i.onload = () => res(i);
    i.onerror = rej;
    i.src = dataUrl;
  });
  let { width, height } = img;
  if (width > height && width > maxSize) { height = (height * maxSize) / width; width = maxSize; }
  else if (height > maxSize) { width = (width * maxSize) / height; height = maxSize; }
  const canvas = document.createElement("canvas");
  canvas.width = width; canvas.height = height;
  const ctx = canvas.getContext("2d");
  ctx.drawImage(img, 0, 0, width, height);
  return canvas.toDataURL("image/jpeg", quality);
}

/**
 * Botão para escolher foto: no celular abre opções (câmera OU galeria).
 * value: data URL base64 (ou null). onChange(newValue).
 */
export default function PhotoPicker({ value, onChange, label = "Foto do membro" }) {
  const fileRef = useRef(null);
  const cameraRef = useRef(null);
  const [loading, setLoading] = useState(false);

  const handleFile = async (e) => {
    const file = e.target.files?.[0];
    e.target.value = "";
    if (!file) return;
    if (!file.type.startsWith("image/")) {
      toast.error("Selecione um arquivo de imagem.");
      return;
    }
    if (file.size > 15 * 1024 * 1024) {
      toast.error("Imagem muito grande (máx 15 MB).");
      return;
    }
    setLoading(true);
    try {
      const compressed = await resizeImage(file);
      onChange(compressed);
    } catch {
      toast.error("Não foi possível processar a imagem.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div>
      <label className="block text-xs uppercase tracking-widest text-terreiro-navy/70 mb-1.5">{label}</label>
      <div className="flex items-center gap-4">
        <div
          className="w-20 h-20 rounded-full overflow-hidden bg-terreiro-ivory border-2 border-terreiro-gold/50 flex items-center justify-center text-terreiro-navy/40"
          data-testid="photo-preview"
        >
          {value ? (
            <img src={value} alt="Prévia da foto" className="w-full h-full object-cover" />
          ) : (
            <ImageIcon size={26} />
          )}
        </div>
        <div className="flex-1 space-y-2">
          <div className="flex flex-wrap gap-2">
            <button
              type="button"
              onClick={() => cameraRef.current?.click()}
              disabled={loading}
              data-testid="photo-camera-btn"
              className="inline-flex items-center gap-2 h-9 px-3 rounded-full text-xs font-semibold bg-terreiro-navy text-terreiro-cream hover:opacity-90 disabled:opacity-60"
            >
              <Camera size={14} /> Câmera
            </button>
            <button
              type="button"
              onClick={() => fileRef.current?.click()}
              disabled={loading}
              data-testid="photo-gallery-btn"
              className="inline-flex items-center gap-2 h-9 px-3 rounded-full text-xs font-semibold bg-terreiro-cream border border-terreiro-gold/40 text-terreiro-navy-deep hover:bg-terreiro-gold/15 disabled:opacity-60"
            >
              <ImageIcon size={14} /> Galeria
            </button>
            {value && (
              <button
                type="button"
                onClick={() => onChange(null)}
                data-testid="photo-remove-btn"
                className="inline-flex items-center gap-2 h-9 px-3 rounded-full text-xs font-semibold bg-terreiro-terracotta/15 text-terreiro-terracotta hover:bg-terreiro-terracotta/25"
              >
                <X size={14} /> Remover
              </button>
            )}
          </div>
          <p className="text-[11px] text-terreiro-navy/60 leading-snug">
            {loading ? "Processando imagem..." : "A imagem é redimensionada e otimizada automaticamente."}
          </p>
        </div>
      </div>
      {/* Hidden inputs: 'capture' força câmera no celular; sem capture abre galeria */}
      <input
        ref={cameraRef}
        type="file"
        accept="image/*"
        capture="user"
        onChange={handleFile}
        className="hidden"
        data-testid="photo-camera-input"
      />
      <input
        ref={fileRef}
        type="file"
        accept="image/*"
        onChange={handleFile}
        className="hidden"
        data-testid="photo-gallery-input"
      />
    </div>
  );
}
