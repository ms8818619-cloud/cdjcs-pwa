import React from "react";
import { BRASAO_URL } from "../lib/api";

export default function Brasao({ size = 160, className = "", glow = true }) {
  return (
    <div
      className={`relative ${className}`}
      style={{ width: size, height: size }}
      data-testid="brasao-emblem"
    >
      {glow && (
        <div
          className="absolute inset-0 rounded-full blur-2xl opacity-40"
          style={{
            background:
              "radial-gradient(circle, rgba(200,168,90,0.7) 0%, rgba(27,58,91,0.15) 55%, transparent 75%)",
          }}
        />
      )}
      <div
        className="relative rounded-full overflow-hidden"
        style={{
          width: size,
          height: size,
          boxShadow:
            "0 0 0 2px rgba(200,168,90,0.55), 0 0 0 6px rgba(27,58,91,0.15), 0 30px 60px -25px rgba(27,58,91,0.55)",
        }}
      >
        <img
          src={BRASAO_URL}
          alt="Brasão da Casa de Jurema Caboclo Samambaia"
          className="w-full h-full object-cover"
          draggable={false}
        />
      </div>
    </div>
  );
}
