import React from "react";
import "@/App.css";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { Toaster } from "sonner";
import { AuthProvider, useAuth } from "@/lib/auth";
import Layout from "@/components/Layout";
import LoginPage from "@/pages/LoginPage";
import WelcomePage from "@/pages/WelcomePage";
import DashboardPage from "@/pages/DashboardPage";
import PaymentPage from "@/pages/PaymentPage";
import EventsPage from "@/pages/EventsPage";
import NoticesPage from "@/pages/NoticesPage";
import AdminPage from "@/pages/AdminPage";

function Guard({ children, admin }) {
  const { user, loading } = useAuth();
  if (loading) return null;
  if (!user) return <Navigate to="/" replace />;
  if (admin && !user.is_admin) return <Navigate to="/app" replace />;
  return children;
}

function PublicOnly({ children }) {
  const { user, loading } = useAuth();
  if (loading) return null;
  if (user) return <Navigate to="/app" replace />;
  return children;
}

function App() {
  return (
    <div className="App">
      <AuthProvider>
        <BrowserRouter>
          <Toaster position="top-center" richColors closeButton />
          <Routes>
            <Route path="/" element={<PublicOnly><LoginPage /></PublicOnly>} />
            <Route path="/bem-vindo" element={<Guard><WelcomePage /></Guard>} />
            <Route path="/app" element={<Guard><Layout /></Guard>}>
              <Route index element={<DashboardPage />} />
              <Route path="contribuicao" element={<PaymentPage />} />
              <Route path="eventos" element={<EventsPage />} />
              <Route path="avisos" element={<NoticesPage />} />
              <Route path="admin" element={<Guard admin><AdminPage /></Guard>} />
            </Route>
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </BrowserRouter>
      </AuthProvider>
    </div>
  );
}

export default App;
