# Casa de Jurema Caboclo Samambaia — C.D.J.C.S

Sistema web para gerenciamento do terreiro **Casa de Jurema Caboclo Samambaia** (fundada em 2022).
Login por CPF, contribuição mensal (Pix + Boleto), calendário de giras/eventos, avisos e painel administrativo completo.

**Stack:** React 19 + Tailwind + shadcn/ui (frontend) · FastAPI + Motor (backend) · MongoDB

---

## 📁 Estrutura do projeto

```
├── backend/          # API FastAPI (Python 3.11+)
│   ├── server.py
│   ├── requirements.txt
│   ├── Procfile
│   ├── runtime.txt
│   └── .env.example
├── frontend/         # React SPA
│   ├── src/
│   ├── public/
│   ├── package.json
│   └── .env.example
├── vercel.json       # Configuração Vercel (frontend)
├── render.yaml       # Configuração Render (backend)
└── README.md
```

---

## 🚀 Deploy gratuito passo a passo

O deploy usa 3 serviços gratuitos:

| Camada | Serviço | Plano gratuito |
|---|---|---|
| Banco de dados | **MongoDB Atlas** | 512 MB grátis |
| Backend (API) | **Render** (ou Railway) | 750h/mês grátis |
| Frontend | **Vercel** | Ilimitado hobby |

### 1) Criar banco de dados no MongoDB Atlas (grátis)

1. Acesse https://www.mongodb.com/cloud/atlas/register e crie uma conta.
2. Crie um **Cluster gratuito M0** (região mais próxima, ex: São Paulo).
3. Em **Database Access**, crie um usuário/senha (anote).
4. Em **Network Access**, adicione `0.0.0.0/0` (permitir de qualquer IP).
5. Em **Connect → Drivers**, copie a *connection string*, algo como:
   ```
   mongodb+srv://USUARIO:SENHA@cluster0.abcd.mongodb.net/?retryWrites=true&w=majority
   ```

### 2) Deploy do Backend no Render (grátis)

1. Suba este projeto para o seu GitHub (seção “Como obter o código” abaixo).
2. Acesse https://render.com e faça login com GitHub.
3. Clique em **New → Web Service** → selecione o repositório.
4. Configure:
   - **Name:** `cdjcs-api` (ou o que preferir)
   - **Root Directory:** `backend`
   - **Runtime:** Python 3
   - **Build Command:** `pip install -r requirements.txt`
   - **Start Command:** `uvicorn server:app --host 0.0.0.0 --port $PORT`
   - **Instance Type:** Free
5. Em **Environment**, adicione:
   - `MONGO_URL` = *(a string do MongoDB Atlas)*
   - `DB_NAME` = `cdjcs`
   - `JWT_SECRET` = *(qualquer texto longo e secreto)*
   - `ADMIN_CPF` = `13480937497` (11 dígitos, sem pontos)
   - `CORS_ORIGINS` = `*`  ← depois do frontend estar no ar, troque para a URL do Vercel
6. Clique em **Create Web Service**. Aguarde ~3 min. Copie a URL, ex: `https://cdjcs-api.onrender.com`.
7. Teste no navegador: `https://cdjcs-api.onrender.com/api/settings` deve retornar JSON com o nome da casa.

> **Alternativa Railway:** https://railway.app → New Project → Deploy from GitHub → root `/backend` → mesmas variáveis. Start command: `uvicorn server:app --host 0.0.0.0 --port $PORT`.

### 3) Deploy do Frontend no Vercel (grátis)

1. Acesse https://vercel.com e faça login com GitHub.
2. Clique em **Add New → Project** → importe o repositório.
3. Configure:
   - **Root Directory:** `frontend`
   - **Framework Preset:** *Create React App* (detectado automaticamente)
   - **Build Command:** `yarn build`
   - **Output Directory:** `build`
4. Em **Environment Variables**, adicione:
   - `REACT_APP_BACKEND_URL` = `https://cdjcs-api.onrender.com` *(a URL do Render)*
5. Clique em **Deploy**. Aguarde ~2 min. Você terá uma URL tipo `https://cdjcs.vercel.app`.

### 4) Ajustar CORS no backend (segurança)

Volte no Render → seu serviço → **Environment** → altere:
- `CORS_ORIGINS` = `https://cdjcs.vercel.app` (URL exata do seu frontend)

Salve — o Render reinicia automaticamente.

### 5) Primeiro acesso

Abra a URL do Vercel. Faça login com o CPF admin: **`134.809.374-97`**.
No **Painel do Admin** cadastre membros, configure o Pix Copia e Cola em Configurações e publique avisos/eventos.

---

## 💻 Rodar localmente

**Pré-requisitos:** Node 18+, Python 3.11+, MongoDB (local ou Atlas), Yarn.

### Backend
```bash
cd backend
cp .env.example .env         # edite MONGO_URL, JWT_SECRET, ADMIN_CPF
pip install -r requirements.txt
uvicorn server:app --reload --port 8001
```

### Frontend
```bash
cd frontend
cp .env.example .env         # REACT_APP_BACKEND_URL=http://localhost:8001
yarn install
yarn start                   # abre em http://localhost:3000
```

---

## 📥 Como obter o código

Para pegar todo este projeto e subir no seu GitHub, na interface do Emergent clique em **“Save to GitHub”**:

1. Menu do chat → **Save to GitHub**.
2. Conecte sua conta GitHub (se ainda não conectou, o botão *Connect GitHub* fica no ícone do seu perfil).
3. Escolha um repositório novo (ou existente) e a branch → **PUSH TO GITHUB**.
4. Depois, no seu terminal:
   ```bash
   git clone https://github.com/SEU_USUARIO/SEU_REPO.git
   cd SEU_REPO
   ```

O código já está **livre de qualquer dependência específica do Emergent** — pronto para o deploy acima em Vercel + Render.

---

## 🔐 Credenciais / configuração inicial

- **Admin default (seed automático no primeiro start):** CPF `13480937497` (formatado `134.809.374-97`) — sem senha, login apenas por CPF.
- **Membros comuns** são cadastrados pelo admin no Painel → aba Membros.
- **Pix / Boleto** são configurados pelo admin em Painel → Configurações. O QR Code é gerado no frontend a partir do código Pix Copia e Cola (via `api.qrserver.com` — sem custo).

Para mudar o CPF admin default: altere `ADMIN_CPF` no Render **antes** do primeiro start. Se quiser trocar depois, edite direto no MongoDB Atlas (coleção `members`).

---

## 🧭 Endpoints principais

| Método | Rota | Descrição |
|---|---|---|
| POST | `/api/auth/login` | Login com `{cpf}` → retorna JWT |
| GET  | `/api/auth/me` | Usuário atual |
| GET  | `/api/settings` | Config pública da casa |
| PUT  | `/api/settings` | Admin: atualizar valor, Pix, boleto, mensagem |
| CRUD | `/api/members` | Admin: gerenciar membros |
| GET  | `/api/payments/me` · `/me/status` | Meus pagamentos e status do mês |
| CRUD | `/api/payments` | Admin: registrar/confirmar/remover |
| CRUD | `/api/events` | Calendário |
| CRUD | `/api/notices` | Avisos |
| GET  | `/api/reports/summary` | Relatório mensal |

Todos os endpoints (exceto `/api/auth/login` e `/api/settings`) exigem `Authorization: Bearer <token>`.

---

## ⚙️ Variáveis de ambiente

### `backend/.env`
```
MONGO_URL="mongodb+srv://usuario:senha@cluster0.xxx.mongodb.net/?retryWrites=true&w=majority"
DB_NAME="cdjcs"
JWT_SECRET="troque-para-uma-senha-forte-aleatoria"
ADMIN_CPF="13480937497"
CORS_ORIGINS="https://cdjcs.vercel.app"
```

### `frontend/.env`
```
REACT_APP_BACKEND_URL=https://cdjcs-api.onrender.com
```

---

## 🎨 Personalização

- **Brasão:** substitua `frontend/public/brasao.jpg` pelo arquivo que quiser (mantendo o nome).
- **Nome da casa / mensagem de boas-vindas:** edite no Painel → Configurações.
- **Cores:** paleta em `frontend/tailwind.config.js` (`terreiro.navy`, `terreiro.gold`, `terreiro.terracotta`, etc.).
- **Fontes:** Cormorant Garamond + Manrope (Google Fonts, `frontend/src/index.css`).

---

## 📄 Licença
Uso interno da Casa de Jurema Caboclo Samambaia. Adapte conforme sua necessidade.

Feito com fé, união e axé 🕊️
